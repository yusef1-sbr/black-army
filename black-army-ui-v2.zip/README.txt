BLACK ARMY UI V2
================

این بسته یک لایهٔ ظاهری جدید برای سایت Flask موجود ایجاد می‌کند و Route/DB/logic را تغییر نمی‌دهد.

ویژگی‌ها:
- تم Dark Military / Cyber
- شیشه‌ای شدن کارت‌ها و فرم‌ها
- نور قرمز و glow
- انیمیشن ورود بخش‌ها هنگام scroll
- شمارندهٔ متحرک آمار
- hover/tilt برای کارت‌ها
- ripple روی دکمه‌ها
- نوار پیشرفت اسکرول
- cursor glow روی دسکتاپ
- ذرات پس‌زمینه روی صفحهٔ عمومی
- منوی موبایل عمومی
- منوی کشویی پنل ادمین روی موبایل
- فعال‌شدن خودکار بخش فعلی در منوی ادمین
- ساعت کوچک داخل پنل
- شمارندهٔ کاراکتر فرم‌ها
- loading state فرم‌ها
- بهبود focus و accessibility
- طراحی جداگانه و حرفه‌ای برای Owner Login
- طراحی جداگانه برای KPI، پیام‌ها، خبرها، روابط، اعضا، افتخارات و تاریخچهٔ پنل

نصب:
1) فایل‌های static/black-army-v2.css و static/black-army-v2.js را داخل static پروژه بگذار.
2) apply_upgrade.py و base.html را در پروژه قرار بده.
3) داخل پوشهٔ black-army اجرا کن:

   python apply_upgrade.py

4) صحت Python لازم نیست تغییر کند؛ بعد Git:

   git add templates/base.html static/black-army-v2.css static/black-army-v2.js apply_upgrade.py
   git commit -m "Upgrade Black Army UI"
   git push origin main

نکته:
- قبل از تغییر base.html نسخهٔ پشتیبان با نام templates/base.html.bak-ui-v2 ساخته می‌شود.
- تغییرات فقط در لایهٔ presentation هستند.
